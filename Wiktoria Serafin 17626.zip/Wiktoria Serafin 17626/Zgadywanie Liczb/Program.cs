﻿using System; // system przestrzen nazw

namespace Zgadywanie_Liczb // nazwa programu
{
    class Program //klasa o nazwie program
    {
        static void Main(string[] args) // metoda main- punkt wejscia aplikacji
        {
            Console.WriteLine("Wiktoria Serafin nr indeksu: 17626");       //wyswietlanie tekstu     
            Menu.StartMenu();  //wywołanie metody ststycznej poprzedzone nazwą klasy
        }
    }
}

