﻿namespace randomnumber
{
    internal class Next
    {
    }
}